# Labs-IA

Grupo:

Alba Yerga 
Adrià Soria 
Ferran Sorde

// subimos también el search.py y el searchAgent.py por si acaso
